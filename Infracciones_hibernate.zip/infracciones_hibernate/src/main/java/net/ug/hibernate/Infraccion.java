package net.ug.hibernate;

import javax.persistence.*;

@Entity
@Table(name = "infraccion")
public class Infraccion {
	@Id
	@Column(name = "id_infraccion")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;

	@Column(name = "infracciones")

	private String lugar;
	private String fecha;
	private String tipo;
	private long id_agente;
	private long id_multa;
	private long id_conductor;
	private long id_hoistorial;

	public Infraccion() {

	}

	public Infraccion(long id, String lugar, String fecha, String tipo, long id_agente, long id_multa,
			long id_conductor, long id_hoistorial) {
		super();
		this.id = id;
		this.lugar = lugar;
		this.fecha = fecha;
		this.tipo = tipo;
		this.id_agente = id_agente;
		this.id_multa = id_multa;
		this.id_conductor = id_conductor;
		this.id_hoistorial = id_hoistorial;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getLugar() {
		return lugar;
	}

	public void setLugar(String lugar) {
		this.lugar = lugar;
	}

	public String getFecha() {
		return fecha;
	}

	public void setFecha(String fecha) {
		this.fecha = fecha;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public long getId_agente() {
		return id_agente;
	}

	public void setId_agente(long id_agente) {
		this.id_agente = id_agente;
	}

	public long getId_multa() {
		return id_multa;
	}

	public void setId_multa(long id_multa) {
		this.id_multa = id_multa;
	}

	public long getId_conductor() {
		return id_conductor;
	}

	public void setId_conductor(long id_conductor) {
		this.id_conductor = id_conductor;
	}

	public long getId_hoistorial() {
		return id_hoistorial;
	}

	public void setId_hoistorial(long id_hoistorial) {
		this.id_hoistorial = id_hoistorial;
	}
	protected void imprimir() {
		
		System.out.println(lugar);
	}
}
