package net.ug.hibernate;

public class main {
	
	
	public static void main (String[] args) {
		crearInfraccion();
		LeerInfraccion();
		ActualizarInfraccion();
		EliminarInfraccion();
	}
	
	public static void crearInfraccion() {
		DaoInfraccion daoinfraccion = new DaoInfraccion();
		Infraccion infraccion = new Infraccion (1,"perimetral","12/12/12","choque",1,2,1,1);	
		daoinfraccion.setup();
		daoinfraccion.crear(infraccion);
		infraccion = new Infraccion(1,"puertoAzul","12/10/12","choque",1,1,1,1);
		daoinfraccion.crear(infraccion);		
	}
	
	public static void LeerInfraccion() {
		DaoInfraccion daoinfraccion = new DaoInfraccion();
		daoinfraccion.setup();
		Infraccion infraccion = daoinfraccion.infraccion(1);
		infraccion.imprimir();
	}

	public static void ActualizarInfraccion() {

		DaoInfraccion daoinfraccion = new DaoInfraccion();
		daoinfraccion.setup();
		Infraccion infraccion = daoinfraccion.infraccion(1);
		infraccion.setId_agente(1);
		daoinfraccion.update(infraccion);
	}
	
	public static void EliminarInfraccion() {
		DaoInfraccion daoinfraccion = new DaoInfraccion();
		daoinfraccion.setup();
		daoinfraccion.delete(1);
		
	}
}
